package com.it.Steps;

import com.it.Pages.DashBoardPage;

public class DashBoardSteps extends DashBoardPage {
}
