package com.it.Steps;

import com.it.Pages.LoginPage;

public class LoginSteps  extends LoginPage {
}
